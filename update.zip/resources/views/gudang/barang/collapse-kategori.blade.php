<div class="collapse" id="collapse-JenisBarang" style="margin-top: 5px">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Tambah Data Jenis Barang</h3>
        </div>
        <div class="panel-body">
            <form method="post" id="frm-JenisBarang">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="form-group">
                        <label for="">Kategori</label>
                        <input type="text" name="kategori" id="kategori" placeholder="Kategori" class="form-control">
                    </div>
                </div>
                <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 col-lg-offset-2">
                    <button class="btn btn-primary btn-flat btn-block btn-md" id="simpan-JenisBarang" type="submit">Simpan <i class="fa fa-save"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>